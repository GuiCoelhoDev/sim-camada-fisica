#include <iostream>
#include "CamadaFisica.hpp"

int main(int argc, char const *argv[])
{
    AplicacaoTransmissora();
    return 0;
}
