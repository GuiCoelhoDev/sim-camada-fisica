Trabalho 3 - Camada Enlace (Controle de Erros) - TR1


Como compilar e executar o código?
1- Entrar dentro da pasta "sim-camada-fisica"
2- Digitar "./compile.sh" no terminal
3- Digitar "./sim-camada-fisica" no terminal
4- Digitar a mensagem que quer enviar para o pontoB e apertar ENTER
5- Digitar a codificação desejada e apertar ENTER
6- Escolher o tipo de enquadramento e apertar ENTER
7- Escolher a estratégia de detecção de erros e dar ENTER